﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Scrummer
{
    public class List
    {
        public int id;
        public string list;

    }
}